
Page({
  data: {
    show: "",
    id:0, //id自增
    list:[
      {'id':'','code':''},
    ],
    ase:[],
    ass:[]//空数组来接受list数据
  },
  onLoad: function () {
    console.log('onLoad');
  },
  //扫一扫并获取值不断递增
  click: function () {
    var that = this;
    var show;
    var i =0;
    wx.scanCode({
      success: (res) => {
        console.log(res);
        var my={};
        let id=this.data.id;//id自增
        id++;//id自增
        my.id=id;
        my.code=res.result;
        let list =that.data.list;//扫码传值
        this.show = res.result;////扫码传值
        list.push(my);
        //时时渲染页面
        that.setData({
          // show: this.show,
          id:id,
          list
        })
        wx.showToast({
          title: '成功',
          icon: 'success',
          duration: 2000
        })
      },
      fail: (res) => {
        wx.showToast({
          title: '失败',
          icon: 'success',
          duration: 2000
        })
      },
      complete: (res) => {
      }
    })
  },
 //发送数据
  send:function(){
    var thta = this;
    let list = this.data.list;//获取整个list的值
    let ase =this.data.ase;//创建一个新的数据来接收list里面的数据
    for(let i=0;i<list.length;i++){
         ase.push(list[i].code);//循环list的code的数据,并把它拼接到ase数组中
    }
    console.log(ase);
  
    wx.request({
      url: 'http://192.168.1.253:8080/cpGood/selectCpGoodId',//地址
      data:{
         gono:ase, //根据地址指定的cod参数将code的值传给后台 
      },
      header: {
     'content-type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json'
      },
      method: 'POST',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
       console.log(res); //成功返回数据给我
      },
      fail: function(res) {},
      complete: function(res) {}, //失败返回报错节点
    })
  },
  //清空数据
  empty:function(){
    var that = this;
    var list =this.data.list;
    var ass =this.data.ass;
    this.setData({
    list:ass
    }) 
  }

})